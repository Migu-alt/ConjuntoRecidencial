/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package principal;

/**
 *
 * @author USURIO
 */
public class ConjuntoRecidencial {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seguridad;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
/**
 *
 * @author USURIO
 */
public class RegistroP {
    
    
    
    public static void guardarUsuario(Propietario propie) throws IOException{
        
        Propietario usuario =propie;
        if (propie != null){
            int aux = usuario.getCedula();
            String cedula = Integer.toString(aux);
            if(verificarCedulaExistente(cedula) == false){
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Propietarios.csv", true))) {
                writer.write(usuario.toCSV());
                writer.newLine();
                System.out.println("Usuario guardado exitosamente.");
                JOptionPane.showMessageDialog(null, "Usuario guardado exitosamente", "Aviso", JOptionPane.ERROR_MESSAGE);                
                }catch (IOException e) {
                System.err.println("Error al escribir en el archivo: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al escribir en el archivo: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
                
        }
            
      
    }
    }
    
    private static boolean verificarCedulaExistente(String cedula) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Propietarios.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] datos = line.split(","); // Supone que los campos están separados por comas
                // Suponiendo que el correo está en la quinta posición (índice 4)
                if (datos.length > 6 && datos[6].equals(cedula)) {
                    JOptionPane.showMessageDialog(null, "El usuario ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                    return true; // El correo ya existe
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Manejo de errores
        }
        return false; // El correo no existe
    }
}
